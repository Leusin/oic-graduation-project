package com.oic.oic

import android.os.Bundle
import android.view.Menu
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager.widget.PagerAdapter
import androidx.viewpager.widget.ViewPager
import com.oic.oic.databinding.ActivityHomeBinding

class HomeActivity : AppCompatActivity() {

    private lateinit var binding : ActivityHomeBinding
    var viewList = ArrayList<View>()

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.sort_order_menu, menu)
        return true
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewList.add(layoutInflater.inflate(R.layout.fragment_search, null))
        viewList.add(layoutInflater.inflate(R.layout.fragment_review, null))
        viewList.add(layoutInflater.inflate(R.layout.fragment_test, null))
        viewList.add(layoutInflater.inflate(R.layout.fragment_graph, null))
        viewList.add(layoutInflater.inflate(R.layout.fragment_settings, null))

        binding.viewPager.adapter = pagerAdapter()

        binding.viewPager.addOnPageChangeListener(object : ViewPager.SimpleOnPageChangeListener() {
            override fun onPageSelected(position: Int) {
                when(position) {
                    0 -> binding.sortMenu.visibility = View.GONE
                    1 -> binding.sortMenu.visibility = View.VISIBLE
                    2 -> binding.sortMenu.visibility = View.GONE
                    3 -> binding.sortMenu.visibility = View.GONE
                    4 -> binding.sortMenu.visibility = View.GONE
                }
                when(position) {
                    0 -> binding.searchBar.visibility = View.VISIBLE
                    1 -> binding.searchBar.visibility = View.GONE
                    2 -> binding.searchBar.visibility = View.GONE
                    3 -> binding.searchBar.visibility = View.GONE
                    4 -> binding.searchBar.visibility = View.GONE
                }
                when(position) {
                    0 -> binding.bottomNavigationView.selectedItemId = R.id.search
                    1 -> binding.bottomNavigationView.selectedItemId = R.id.review
                    2 -> binding.bottomNavigationView.selectedItemId = R.id.test
                    3 -> binding.bottomNavigationView.selectedItemId = R.id.graph
                    4 -> binding.bottomNavigationView.selectedItemId = R.id.settings

                }
                when(position) {
                    0 -> binding.pageTitle.text = "학습하기"
                    1 -> binding.pageTitle.text = "즐겨찾기"
                    2 -> binding.pageTitle.text = "시험보기"
                    3 -> binding.pageTitle.text = "학습현황"
                    4 -> binding.pageTitle.text = "설정"
                }
            }
        })
        binding.bottomNavigationView.setOnNavigationItemSelectedListener {
            when(it.itemId){
                R.id.search -> binding.viewPager.setCurrentItem(0)
                R.id.review -> binding.viewPager.setCurrentItem(1)
                R.id.test -> binding.viewPager.setCurrentItem(2)
                R.id.graph -> binding.viewPager.setCurrentItem(3)
                R.id.settings -> binding.viewPager.setCurrentItem(4)
            }
            return@setOnNavigationItemSelectedListener true
        }
        binding.searchBar.maxWidth = Int.MAX_VALUE
        binding.searchBar.isSubmitButtonEnabled = true
        binding.searchBar.queryHint = "사전 검색"
    }

    inner class pagerAdapter : PagerAdapter() {
        override fun isViewFromObject(view: View, `object`: Any) = view == `object`

        override fun getCount(): Int = viewList.size

        override fun instantiateItem(container: ViewGroup, position: Int): Any {
            var curView = viewList[position]
            binding.viewPager.addView(curView)
            return curView
        }

        override fun destroyItem(container: ViewGroup, position: Int, `object`: Any) {
            binding.viewPager.removeView(`object` as View)
        }
    }
}