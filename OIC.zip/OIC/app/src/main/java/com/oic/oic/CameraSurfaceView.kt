package com.oic.oic

class CameraSurfaceView {
    var surfaceView: CameraSurfaceView? = null


}